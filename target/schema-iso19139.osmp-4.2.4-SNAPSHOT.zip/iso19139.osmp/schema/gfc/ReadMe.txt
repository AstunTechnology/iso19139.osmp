
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-02-26, IGN / France - Nicolas Lesage / Marcellin Prudham)
