
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)


**************************

Package gml from the OGC published GML 3.2.1 schemas from OGC 07-036 (schemas repository http://schemas.opengis.net/) modified as follows :

- gmlBase.xsd line14: 
schemaLocation="../../xlink/1.0.0/xlinks.xsd"
replaced by
schemaLocation="../xlink/xlinks.xsd"

- referenceSystems.xsd line12:
schemaLocation="../../iso/19139/20070417/gmd/gmd.xsd"
replaced by
schemaLocation="../gmd/gmd.xsd"

- coordinateOperations.xsd line16:
schemaLocation="../../iso/19139/20070417/gmd/gmd.xsd"
replaced by
schemaLocation="../gmd/gmd.xsd"